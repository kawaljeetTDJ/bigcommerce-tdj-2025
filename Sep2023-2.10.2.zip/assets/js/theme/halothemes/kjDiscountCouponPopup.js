function discountCopyCoupon() {
    const couponElement = document.getElementById('couponCode');
    const popupWrapper = document.getElementById('kj-discount-popup');
    const couponContainer = document.querySelector('.discount-popup-container');

    if (!couponElement) {
        alert('Required element not found.');
        return;
    }

    const coupon = couponElement.innerText.trim();

    if (navigator.clipboard && coupon) {
        navigator.clipboard.writeText(coupon)
            .then(() => {
                // Create a success message
                const message = document.createElement('span');
                message.className = 'coupon-success-message';
                message.textContent = 'Coupon code copied!';
                
                // Avoid duplicating the message if already present
                if (!couponContainer.querySelector('.coupon-success-message')) {
                    couponContainer.appendChild(message);
                }

                // Hide popup after 2 seconds
                setTimeout(() => {
                    popupWrapper.classList.add('hide');
                }, 1500);
            })
            .catch(() => {
                alert('Failed to copy coupon code. Please copy it manually.');
            });
    } else {
        alert('Clipboard not supported in this browser. Please copy manually.');
    }
}

// window.discountCopyCoupon = discountCopyCoupon;

export default discountCopyCoupon;
